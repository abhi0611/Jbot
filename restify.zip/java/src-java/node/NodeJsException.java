package node;

public class NodeJsException extends RuntimeException {
    public NodeJsException(String message) {
        super(message);
    }
}
