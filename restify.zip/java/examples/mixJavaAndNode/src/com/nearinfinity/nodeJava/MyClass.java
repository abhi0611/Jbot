package com.nearinfinity.nodeJava;

public class MyClass {
  public static int addNumbers(int a, int b) {
    return a + b;
  }
}
