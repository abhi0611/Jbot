public interface ListenerInterface {
    void onEvent(java.util.ArrayList<String> list, java.lang.Runtime runtime);
}