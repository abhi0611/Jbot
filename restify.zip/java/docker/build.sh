#!/bin/bash

docker build -t joeferner/node-java .
